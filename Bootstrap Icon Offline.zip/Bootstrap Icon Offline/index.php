<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bootstrap Offline</title>
    <link rel="stylesheet" href="./bootstrap/css/bootstrap.min.css">
    <link href="./bootstrap_icons/font/bootstrap-icons.css" rel="stylesheet">
</head>

<body>
    <!-- Your content here -->
    <h1>Test Heading</h1>
    <br>
    <div class="text-primary m-5">
        <h1>
            <i class="bi bi-0-square-fill "></i>
            <br>
            <i class="bi bi-qr-code"></i>
        </h1>
    </div>
    <!-- Include jQuery and then Bootstrap Bundle JS (includes Popper.js) -->
    <script src="./bootstrap/jquery-3.7.1.min.js"></script>
    <script src="./bootstrap/js/bootstrap.bundle.min.js"></script>
</body>

</html>